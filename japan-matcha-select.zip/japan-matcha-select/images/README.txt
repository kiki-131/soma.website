JAPAN MATCHA SELECT — IMAGE REQUIREMENTS

All production images should be optimized WebP files, use an sRGB color profile,
and balance premium Japanese aesthetics with natural light and restrained styling.

1. hero-matcha.webp
Recommended size: 1600 x 1200 px or larger
Aspect ratio: 4:3 (composition must also allow a 4:5 crop on mobile)
Content: Matcha tea bowl, bamboo whisk, fine matcha powder, natural light, minimal styling
Alt text: Ceremonial matcha in a Japanese tea bowl with a bamboo whisk

2. ceremonial-matcha.webp
Recommended size: 1200 x 900 px or larger
Aspect ratio: 4:3 or 16:10
Content: Premium ceremonial-grade matcha with elegant traditional preparation
Alt text: Premium ceremonial-grade Japanese matcha

3. cafe-matcha.webp
Recommended size: 1200 x 900 px or larger
Aspect ratio: 4:3 or 16:10
Content: Refined matcha latte or café preparation in a contemporary setting
Alt text: Japanese matcha prepared for café lattes

4. culinary-matcha.webp
Recommended size: 1200 x 900 px or larger
Aspect ratio: 4:3 or 16:10
Content: Matcha powder with understated baking, dessert, or culinary context
Alt text: Culinary Japanese matcha powder for baking and desserts

5. retail-matcha.webp
Recommended size: 1200 x 900 px or larger
Aspect ratio: 4:3 or 16:10
Content: Premium, consumer-ready Japanese matcha packaging on a clean retail display
Alt text: Consumer-ready Japanese matcha products for retail

6. japanese-tea-field.webp
Recommended size: 1600 x 1200 px or larger
Aspect ratio: 4:3
Content: Japanese green tea fields, soft natural light, uncluttered composition
Alt text: Green tea fields in Japan where matcha leaves are cultivated

Optimization target: generally 150–300 KB per image where visual quality permits.
Keep the exact filenames above unless the corresponding src values in index.html are updated.
