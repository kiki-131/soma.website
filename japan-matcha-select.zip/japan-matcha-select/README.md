# Japan Matcha Select LP

## Overview

An independent English B2B landing page for introducing curated Japanese matcha to international retailers, cafés, restaurants, hotels, distributors, importers, and e-commerce businesses. Its primary conversion is the Faire wholesale shop; the secondary conversion is a direct wholesale inquiry.

The package uses only HTML5, CSS3, and Vanilla JavaScript and has no framework or build-step dependency.

## File Structure

```text
japan-matcha-select/
├── index.html          # Page content, links, metadata, and JSON-LD
├── css/style.css       # Design system, layouts, components, responsive rules
├── js/main.js          # Navigation, FAQ, scrolling, form placeholder, effects
├── images/README.txt   # Required production-image specifications
└── README.md           # Integration guide
```

## Installation

1. Copy the complete `japan-matcha-select` directory to the web server.
2. Add the six optimized images listed in `images/README.txt` to `images/`.
3. Configure the Faire links and contact form described below.
4. Serve `index.html` at `/japan-matcha-select/`.

No package installation, compilation, or bundling is required. For local preview, use a local HTTP server rather than opening the HTML with the `file://` protocol.

## Faire URL

The temporary Faire URL is `https://www.faire.com/`. Search `index.html` for that exact string and replace every occurrence. It appears in the header, hero, Faire CTA, final CTA, and footer. Faire URLs intentionally live in HTML, not CSS or JavaScript.

## Contact Form

The inquiry form is in `index.html` under `<section id="inquiry">`. It currently uses `action="#"`. Production integration must replace this action and adapt or remove the submit listener under “Development placeholder” in `js/main.js`.

Until integration, JavaScript prevents submission and writes `Form submission endpoint needs to be configured.` to the browser console. The visible confirmation is also a development placeholder. Keep server-side validation, spam protection, consent/privacy handling, and success/error responses in the final implementation.

## Images

Place images in `images/` using the exact filenames documented in `images/README.txt`. The HTML contains intrinsic width and height attributes to reduce layout shift. Product and tea-field images are lazy-loaded; the above-the-fold hero image is not.

CSS background colors provide a visual fallback if image requests fail, but production images are required before launch.

## Links

SOMA links can be changed directly in `index.html`:

- About SOMA: `https://soma-jp.net/`
- Privacy Policy: `https://soma-jp.net/privacy-policy/`
- Contact / producer partnership: `https://soma-jp.net/contact/`

External Faire links open in a new tab and use `rel="noopener"`.

## SEO

Edit the `<head>` of `index.html` to change the title, meta description, robots directive, Open Graph values, and canonical URL. The current canonical URL is `https://soma-jp.net/japan-matcha-select/`.

Two JSON-LD blocks provide `Organization` and `FAQPage` structured data. If FAQ copy changes on-page, update the matching FAQ JSON-LD answers at the same time. Do not add business claims or contact details without verified data.

## Fonts

Google Fonts are loaded from `fonts.googleapis.com`:

- Cormorant Garamond: headings and brand display
- Manrope: body copy, navigation, controls, and buttons

If SOMA's content security policy blocks Google Fonts, self-host licensed WOFF2 files or replace the font stacks in `css/style.css`.

## JavaScript

`js/main.js` implements:

- Accessible mobile navigation, including Escape-key closing
- FAQ accordion with `aria-expanded` and `hidden` state updates
- Same-page smooth scrolling with reduced-motion support
- HTML5 form validation and non-submitting development placeholder
- Current footer year
- Lightweight IntersectionObserver entrance effects

The page remains readable if JavaScript is unavailable, except the mobile navigation and accordion interactions.

## Integration Notes

- Keep IDs unchanged unless all corresponding navigation anchors and `aria-controls` values are updated.
- Scope or rename CSS classes if the existing CMS theme uses conflicting global selectors. The stylesheet contains intentional base element styles for this standalone package.
- In WordPress, enqueue `css/style.css` and `js/main.js`; do not paste duplicate Google Font imports if the theme already loads them.
- Ensure the page template does not add a second `<main>`, `<h1>`, canonical tag, or conflicting JSON-LD.
- Preserve source order and semantic landmarks for accessibility.
- Test CSP rules for Google Fonts and inline JSON-LD.
- Connect the form to SOMA's approved backend and privacy workflow before launch.
- Recheck all absolute URLs after deployment and add an Open Graph image if required by the hosting template.
- Clear CDN/page caches after replacing assets.
